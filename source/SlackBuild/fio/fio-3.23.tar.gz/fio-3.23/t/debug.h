#ifndef FIO_DEBUG_INC_H
#define FIO_DEBUG_INC_H

extern void debug_init(void);

#endif
