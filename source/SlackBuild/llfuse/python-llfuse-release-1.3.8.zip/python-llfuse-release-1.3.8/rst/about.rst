=======
 About
=======

.. include:: ../README.rst
   :start-after: start-intro
