====================
 FUSE API Functions
====================

.. currentmodule:: llfuse

.. autofunction:: init
.. autofunction:: main
.. autofunction:: close
.. autofunction:: invalidate_inode
.. autofunction:: invalidate_entry
.. autofunction:: notify_store
.. autofunction:: get_ino_t_bits
.. autofunction:: get_off_t_bits
