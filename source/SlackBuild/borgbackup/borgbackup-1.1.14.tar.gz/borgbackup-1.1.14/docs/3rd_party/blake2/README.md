# BLAKE2

This is the reference source code package of BLAKE2.

All code is triple-licensed under the [CC0](http://creativecommons.org/publicdomain/zero/1.0),
the [OpenSSL Licence](https://www.openssl.org/source/license.html),
or the [Apache Public License 2.0](http://www.apache.org/licenses/LICENSE-2.0),
at your choosing.

More: [https://blake2.net](https://blake2.net). [GitHub repository](https://github.com/BLAKE2/BLAKE2).

Contact: contact@blake2.net

