#ifdef BORG_USE_LIBLZ4
#include <lz4.h>
#else
#include "lz4/lib/lz4.h"
#endif
