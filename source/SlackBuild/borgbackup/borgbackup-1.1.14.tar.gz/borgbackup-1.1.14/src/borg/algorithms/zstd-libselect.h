#ifdef BORG_USE_LIBZSTD
#include <zstd.h>
#else
#include "zstd/lib/zstd.h"
#endif
