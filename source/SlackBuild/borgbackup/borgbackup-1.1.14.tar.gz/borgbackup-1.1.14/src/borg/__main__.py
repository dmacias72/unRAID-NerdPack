from borg.archiver import main
main()
