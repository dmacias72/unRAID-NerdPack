#!/usr/bin/env python
# encoding: utf-8

"""Init triggering goes here.

This code will be executed first when doing:

    $ python -m shredder
"""

import shredder

shredder.run_gui()
