#!/bin/sh

git clone https://github.com/adrianlopezroche/fdupes.git
cd fdupes
make
