Debian package
==============

It is maintained outside of the rmlint source tree by e7appew:

    https://github.com/e7appew/rmlint/tree/debian

Please redirect any feedback to him. Thank you!
