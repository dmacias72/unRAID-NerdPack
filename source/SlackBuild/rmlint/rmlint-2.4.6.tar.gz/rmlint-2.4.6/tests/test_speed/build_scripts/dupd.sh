#!/bin/sh

git clone https://github.com/jvirkki/dupd
cd dupd
make -j4
