#ifndef SHEEPHASH_H_INCLUDED
#define SHEEPHASH_H_INCLUDED

uint64_t cfarmhash(const char *, size_t);

#endif /* SHEEPHASH_H_INCLUDED */
